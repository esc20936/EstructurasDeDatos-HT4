public class StackFactory{
    public Stack getStackImplementation(String identifier,int size){
        Stack obj =null;
        switch (identifier){
            case "arraylist":
                obj = new StackArrayList();
                break;
            case "vector":
                obj = new StackVector(size);
                break;
            case "simples":
                obj = new StackList();
                break;
            case "dobles":
                obj = new StackDoubleLinkedList();
                break;
            default:
             obj = null;
            break;
        }
        return obj;
    }
}