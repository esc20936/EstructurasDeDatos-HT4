import java.util.Scanner;
public class Driver{
    public static void print(String message){
        System.out.println(message);
    }
    public static void print(char message){
        System.out.println(message);
    }
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        StackFactory sf = new StackFactory();
        VectorCalculadora vector = new VectorCalculadora();
        String operaciones = vector.decode("datos.txt");
        String[] lineas = operaciones.split("\n");
        Stack myStack = null;
        String tipo="";

        /*****************************      SOLICITUD DE LA IMPLEMENTACION A UTILIZAR ********************************/
        /*************************************************************************************************************/
        boolean bandera=true;
        while(bandera){
            print("Con que implementacion deseas trabajar: (ArrayList,Vector,Lista)");
            tipo=input.nextLine();
            if(tipo.toLowerCase().equals("arraylist") || tipo.toLowerCase().equals("vector") || tipo.toLowerCase().equals("lista")){
                if(tipo.toLowerCase().equals("lista")){
                    print(" Desea trabajar con listas: (simples,dobles)");
                    String tipo2 = input.nextLine();
                    if(tipo2.toLowerCase().equals("simples") || tipo2.toLowerCase().equals("dobles")){
                        tipo = tipo2.toLowerCase();           
                    }else{
                        tipo = null;
                        print("\nINGRESA UNA OPCION VALIDA");
                    }    
                }
            }else{
                tipo = null;
                print("\nINGRESA UNA OPCION VALIDA");
            }
        
            bandera = (tipo==null);
        }
        tipo = tipo.toLowerCase();
        /**************************************************************************************************************/
        

        /********************************    CALCULO DE LOS RESULTADOS         *********************************/
        /**************************************************************************************************************/
        int cont = 0;
        int cont1 = 0;

        for(String linea : lineas){
            for(int i = 0; i < linea.length();i++){
                if(linea.charAt(i)!= ' '){
                    cont1++;
                }
            }

            myStack = sf.getStackImplementation(tipo,cont1);
        
            for(int i = 0; i < linea.length();i++){
                if(linea.charAt(i)!= ' '){
                    myStack.push(linea.charAt(i));
                }
            }

            Stack stack1 = sf.getStackImplementation(tipo,cont1);

                for(int i = myStack.count(); i>0; i--){
                    char valor =(char) myStack.pop();
                    stack1.push(valor);
                }
            print("El resultado de la linea "+(++cont)+" es: "+ vector.operar(stack1));
            print("**********************************************");
        }
        /**************************************************************************************************************/
        
    }
}
