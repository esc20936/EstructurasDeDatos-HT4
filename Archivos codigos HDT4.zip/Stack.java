/**
 * 
 */
//package main;

/**
 * @author moise
 *
 */
public abstract class Stack<E> implements IStack<E> {

}
