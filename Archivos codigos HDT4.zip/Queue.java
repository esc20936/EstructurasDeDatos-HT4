/**
 * 
 */
//package main;


/**
 * @author moises
 *
 */
public abstract class Queue<E> implements IQueue<E>{
	
}
